package com.clevertap.ui.campaign_tests.mobile_push;

import com.clevertap.BaseTest;

public class Recurring extends BaseTest {
}
