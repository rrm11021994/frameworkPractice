package com.clevertap.ui.pages;

public class SettingsCampaignIntegrationLimitsWebPushPage {
}
